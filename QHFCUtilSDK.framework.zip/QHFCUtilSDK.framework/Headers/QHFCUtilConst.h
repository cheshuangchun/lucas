//
//  QHFCUtilConst.h
//  QHFCUtilsDemo
//
//  Created by cheshuangchun on 2021/4/1.
//

#ifndef QHFCUtilConst_h
#define QHFCUtilConst_h

#define FCISIphoneX ({\
int tmp = 0;\
if (@available(iOS 11.0, *)) {\
if ([UIApplication sharedApplication].delegate.window.safeAreaInsets.top > 20 || [UIApplication sharedApplication].delegate.window.safeAreaInsets.left > 20) {\
tmp = 1;\
}else{\
tmp = 0;\
}\
}else{\
tmp = 0;\
}\
tmp;\
})

#define kScreenW [UIScreen mainScreen].bounds.size.width
#define kScreenH [UIScreen mainScreen].bounds.size.height

#endif /* QHFCUtilConst_h */
