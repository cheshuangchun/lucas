//
//  QHFCSmartGCDDelay.h
//  QHSoundBoxApp
//
//  Created by cheshuangchun on 2018/8/31.
//  Copyright © 2018年 qihoo. All rights reserved.
//

#import <Foundation/Foundation.h>

//@interface QHFCSmartGCDDelay : NSObject
typedef void(^GCDTask)(BOOL cancel);
typedef void(^gcdBlock)(void);

@interface QHFCSmartGCDDelay : NSObject

+(GCDTask)gcdDelay:(NSTimeInterval)time task:(gcdBlock)block;
+(void)gcdCancel:(GCDTask)task;

@end
