//
//  QSLAPC_ECCrypto.h
//  QSLAPConfigSDK
//
//  Created by wangdacheng on 2019/11/19.
//  Copyright © 2019 QiShare. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, APCEllipticCurve) {
    APCEllipticCurve_None = 0,
    APCEllipticCurve_Secp128r1 = 128,
    APCEllipticCurve_Secp192r1 = 192,
    APCEllipticCurve_Secp256r1 = 256,
    APCEllipticCurve_Secp384r1 = 384,
};

NS_ASSUME_NONNULL_BEGIN

@interface QSLAPC_ECCrypto : NSObject

//! 公钥
@property (nonatomic, strong) NSData *publicKey;
//! 私钥
@property (nonatomic, strong) NSData *privateKey;

/*!
 @brief 使用curve初始化加密类对象
 @param curve 椭圆曲线类型
 @return QSLEllipticCurve实例
 */
+ (instancetype)cryptoWithCurve:(APCEllipticCurve)curve;

/*!
 @brief 生成秘钥
 @param publicKey 另一个QSLEllipticCurve的公钥
 @return 秘钥数据
 */
- (NSData *)sharedSecretWithPublicKey:(NSData *)publicKey;

@end

NS_ASSUME_NONNULL_END
