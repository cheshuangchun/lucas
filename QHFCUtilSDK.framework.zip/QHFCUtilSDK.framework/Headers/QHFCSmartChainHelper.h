//
//  QHFCSmartChainHelper.h
//  QHUploadLogsSDK
//
//  Created by cheshuangchun on 2020/9/24.
//  Copyright © 2020 qihoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
NS_ASSUME_NONNULL_BEGIN

@interface QHFCSmartChainHelper : NSObject
@property (nonatomic, strong) NSString *service;

+ (instancetype)keyChainHelperForService:(NSString *)service;



- (BOOL)addItem:(NSData *)data errorMsg:(NSString **)errorMsg accessControl:(BOOL)accessControl;

// aizhongyuan add 2014.12.19
- (OSStatus)addItem:(NSData *)data errorMsg:(__autoreleasing NSString **)anErrorMsg protection:(CFTypeRef)protection;

- (BOOL)updateItem:(NSData *)data prompt:(NSString *)prompt errorMsg:(NSString *_Nullable*_Nullable)errorMsg;
- (BOOL)deleteItemAndReturnErrorMsg:(NSString **)errorMsg;
- (NSData *)queryItem:(NSString *)prompt errorMsg:(NSString **)errorMsg;

// aizhongyuan add 2014.12.19
- (NSData *)queryItem:(NSString **)anErrorMsg;
- (BOOL)updateItem:(NSData *)data errorMsg:(NSString **)anErrorMsg;
@end

NS_ASSUME_NONNULL_END
