//
//  UIColor+Category.h
//  QHSoundBoxApp
//
//  Created by cheshuangchun on 2018/6/26.
//  Copyright © 2018年 qihoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (FCCategory)
+ (UIColor *)colorSWithHexString:(NSString *)stringToConvert;

//支持rgb,argb
+ (UIColor *)colorWithHextSColorString:(NSString *)hexColorString alpha:(CGFloat)alphaValue;
@end
