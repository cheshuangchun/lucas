//
//  QHFCSmartUtils.h
//  QHQuickLinkSDK
//
//  Created by cheshuangchun on 2019/6/24.
//  Copyright © 2019 qihoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface QHFCSmartUtils : NSObject
/*
 * 判断是否为空
 */
#pragma mark 判断是否为空
+(NSString *)YRIsEmptString:(id )obj;
/**
 *  设备唯一编号
 *
 *  @return 设备唯一编号
 */
+(NSString*)getDeviceUuid;
/**
 十进制转换十六进制
 
 @param decimal 十进制数
 @return 十六进制数
 */
+ (NSString *)getHexByDecimal:(NSInteger)decimal;
/**
 当前时间的时间戳
 */
+(NSString*)getCurrentTimestamp;
/**
 时间转毫秒
 @param datetime 时间
 @return 毫秒
 */
+(long long)getDateTimeTOMilliSeconds:(NSDate *)datetime;
/**
 字典转json串
 @param dict 字典 或 数组
 @return json字符串
 */
+(NSString *)convertToJsonData:(id)dict;
/**
 MD5加密
 */
#pragma mark  MD5 加签
+(NSString *) md5:(NSString *) input;
/**
 json 转字典
 */
+(NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;

/**
 根据errorCode显示不同的错误信息
 */
+(NSString *)getErrorMessageWithErrorCode:(NSString *)errorCode;


+(UIImage *)getImage:(NSString *)imgName;

/**
 保存wifi到文件
 */
+(void)saveWifiNameToFile:(NSString *)wifiName pwd:(NSString *)pwd;

/**
 从文件读取wifi数组
 */
+(NSArray *)readWifiNameFromFile;


/// 获取navibar高度
+(CGFloat)getNaviBarHeight;

+ (CGFloat)statusBarHeight;


+ (void)showHUD;
+ (void)hideHUD;
+ (void)showToastMsg:(NSString *)msg;
+ (NSString *)randomPassword;
/*
 * 获取不带行高的文字高度
 */
+ (CGSize)sizeMake:(NSString *)str font:(CGFloat)font width:(CGFloat)width;

/// 获取快联的code
+ (NSString *)getSmartFastCode;

+ (NSBundle *)bundleWithName;


/// 保存错误日志到内存
/// @param timeout 是否超时错误  YES 是  NO 不是
/// @param type 0 表示蓝牙连接  1 表示ap联网 2 声波配网超时  3 二维码配网超时
/// @param value 错误的value
+ (void)saveErrorLog:(BOOL)timeout type:(NSInteger)type errorValue:(NSString *)value;


//+ (void)test999;
//单个文件的大小
+ (long long) fileSizeAtPath:(NSString*) filePath;


+(NSString*) getBundleID;

+ (NSDate *)getLocalDate;

+ (NSString *)getCurrentLanguage;

+ (NSInteger)getUTCZone;

+ (void)saveDeviceInfos:(NSArray *)deviceInfos;

+ (NSArray * )getCachedDeviceInfos;

//NSDate转NSString
+(NSString*)qh_stringFromDate:(NSDate*)date;

//计算时间差
+ (NSTimeInterval)pleaseInsertStarTime:(NSString *)starTime andInsertEndTime:(NSString *)endTime;
@end

NS_ASSUME_NONNULL_END
