//
//  NSString+SpeakerAdditions.h
//  QHQuickLinkSDK
//
//  Created by cheshuangchun on 2019/6/24.
//  Copyright © 2019 qihoo. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface NSString (Additions)
-(NSString *)URLEncodedString;
-(NSString *)URLDecodedString;
///去掉前后空格
+ (NSString *)trimWhitespace:(NSString *)val;

/**
 *  获取指定字体的字符串的长度
 *
 *  @param font 字符串的字体
 *
 *  @return 字符串的长度
 */
- (double)getWidthWithStringFont:(UIFont *)font;
@end

NS_ASSUME_NONNULL_END
