//
//  NSData+SwitchData.h
//  AsyncSocketMac
//
//  Created by cheshuangchun on 2019/12/12.
//  Copyright © 2019 Shuqy. All rights reserved.
//


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSData (FCSwitchData)
/**
 NSData 转  十六进制string
 
 @return NSString类型的十六进制string
 */
- (NSString *)convertDataToHexStrT;
- (NSString *)utf8String;
- (NSData *)UTF8Data;
@end

NS_ASSUME_NONNULL_END
