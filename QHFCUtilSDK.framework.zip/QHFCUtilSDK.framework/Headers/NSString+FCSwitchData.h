//
//  NSString+SwitchData.h
//  AsyncSocketMac
//
//  Created by cheshuangchun on 2019/12/12.
//  Copyright © 2019 Shuqy. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (FCSwitchData)
/**
 十六进制转十进制
 
 @return 十进制字符串
 */
- (NSString *)hexToDecimal;
@end

NS_ASSUME_NONNULL_END
