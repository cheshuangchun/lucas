//
//  QHFCSmartGCDTimer.h
//  QHQuickLinkSDK
//
//  Created by cheshuangchun on 2019/12/18.
//  Copyright © 2019 qihoo. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QHFCSmartGCDTimer : NSObject
@property (strong, readonly, nonatomic) dispatch_source_t dispatchSource;

#pragma 初始化
- (instancetype)init;
- (void)event:(dispatch_block_t)block timeInterval:(uint64_t)interval delay:(uint64_t)delay;
- (void)start;
- (void)destroy;
@end

NS_ASSUME_NONNULL_END
