//
//  QSLAPC_ECCryptor.h
//  QSLAPConfigSDK
//
//  Created by wangdacheng on 2019/11/19.
//  Copyright © 2019 QiShare. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QSLAPC_ECCryptor : NSObject

//! sha1加密算法
+ (NSString *)sha1:(NSString *)input;
+ (NSString *)sha1:(NSString *)input suffix:(NSUInteger)suffix;

//! RC4加密/解密
+ (NSString *)rc4EncryptString:(NSString *)string withKey:(NSString *)key;
+ (NSString *)rc4DecryptString:(NSString *)string withKey:(NSString *)key;

//! AES加密/解密
+ (NSString *)aesEncryptString:(NSString *)string withKey:(NSString *)key;
+ (NSString *)aesDecryptString:(NSString *)string withKey:(NSString *)key;


+ (NSData *)getAesDataDecryptString:(NSString *)string withKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
